# EyeCare Academy — starter app

A bilingual (English + Urdu) cross-platform educational app starter built with Expo and React Native.

## Included in this starter
- Home dashboard and navigation
- Starter disease encyclopedia with bilingual names/summaries
- Equipment directory
- Anatomy and physiology learning areas
- Optometry, investigations, and treatments module placeholders
- Interactive sample MCQ quiz
- Educational safety notices

## Run locally
1. Install Node.js (LTS).
2. Install dependencies: `npm install`
3. Start Expo: `npx expo start`
4. Scan the QR code using Expo Go, or run `npm run android` / `npm run ios`.

## Important
This is a working starter foundation, not a finished medical reference or a store-published app. The disease and equipment content is a small sample set and must be expanded and clinically reviewed by qualified ophthalmology/optometry professionals before public release. The current Urdu support covers key labels and selected summaries; a complete translation pass is still needed. The app does not diagnose patients or provide individualized treatment.

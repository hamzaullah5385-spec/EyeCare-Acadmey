# Content roadmap

## Content library expansion
- Anterior segment: cornea, conjunctiva, sclera, tear film, lids and lacrimal system
- Lens and cataract
- Glaucoma and optic neuropathy
- Retina and vitreous
- Uveitis
- Neuro-ophthalmology
- Pediatric ophthalmology and strabismus
- Ocular trauma and emergencies
- Refractive error, contact lenses and binocular vision
- Ocular pharmacology
- Clinical equipment, imaging and investigations
- Ophthalmic procedures and surgery

## Standard disease article template
Definition; classification; anatomy; risk factors; pathophysiology; symptoms; signs; differential diagnosis; investigations; management principles; complications; red flags; clinical case; MCQs; references; English/Urdu glossary.

## Quality and safety
All clinical material should be referenced to current, reputable guidelines and reviewed by qualified clinicians. Keep emergency warning signs prominent. Never present the app as a diagnostic device or a substitute for in-person care.
